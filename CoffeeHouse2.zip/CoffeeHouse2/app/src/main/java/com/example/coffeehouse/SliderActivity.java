package com.example.coffeehouse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class SliderActivity extends AppCompatActivity {

    private OnBoardingActivity onBoardingActivity;
    private LinearLayout layoutOnBoardingIndicators;
    private MaterialButton buttonOnBoardingAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slider);

        layoutOnBoardingIndicators = findViewById(R.id.layoutOnboardingIndicators);
        buttonOnBoardingAction = findViewById(R.id.buttonOnboardingAction);

        setupOnBoardingItems();

        ViewPager2 onBoardingViewPager = findViewById(R.id.onboardingViewPager);
        onBoardingViewPager.setAdapter(onBoardingActivity);

        setupOnBoardingIndicators();
        setCurrentOnBoardingIndicator(0);

        onBoardingViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                setCurrentOnBoardingIndicator(position);
            }
        });

        buttonOnBoardingAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onBoardingViewPager.getCurrentItem() + 1 < onBoardingActivity.getItemCount()) {
                    onBoardingViewPager.setCurrentItem(onBoardingViewPager.getCurrentItem() + 1);
                } else {
                    startActivity(new Intent(getApplicationContext(), MapActivity.class));
                    finish();
                }
            }
        });
    }

    private void setupOnBoardingItems(){
        List<OnBoardingItem> onBoardingItems = new ArrayList<>();

        OnBoardingItem itemStart1 = new OnBoardingItem();
        itemStart1.setTitle("Привет!");
        itemStart1.setDescription("Coffee toGo – это приложение в котором вы можете заказать кофе онлайн и забрать его в близжайшей к вам кофейне.\n" +
                "Сейчас расскажем как оно работает");
        itemStart1.setImage(R.drawable.image1);

        OnBoardingItem itemStart2 = new OnBoardingItem();
        itemStart2.setTitle("Поиск кофейни");
        itemStart2.setDescription("На карте указаны близжайшие к вам кофейни, выбирайте наиболее удобную для вас. Приложение подскажет как долго до неё идти.");
        itemStart2.setImage(R.drawable.image2);

        OnBoardingItem itemStart3 = new OnBoardingItem();
        itemStart3.setTitle("Оформление заказа");
        itemStart3.setDescription("Выбирайте свои любимые напитки и десерты. Вы можете изменить их состав и выбрать время, когда вам будет удобно их забрать.");
        itemStart3.setImage(R.drawable.image3);

        OnBoardingItem itemStart4 = new OnBoardingItem();
        itemStart4.setTitle("Получение заказа");
        itemStart4.setDescription("В указанное время приходите в кофейню и наслаждайтесь вкусом кофе, без очереди и ожидания.");
        itemStart4.setImage(R.drawable.image4);

        onBoardingItems.add(itemStart1);
        onBoardingItems.add(itemStart2);
        onBoardingItems.add(itemStart3);
        onBoardingItems.add(itemStart4);

        onBoardingActivity = new OnBoardingActivity(onBoardingItems);
    }

    private void setupOnBoardingIndicators(){
        ImageView[] indicators = new ImageView[onBoardingActivity.getItemCount()];
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(8 , 0, 8, 0);
        for (int i = 0; i < indicators.length; i++) {
            indicators[i] = new ImageView(getApplicationContext());
            indicators[i].setImageDrawable(ContextCompat.getDrawable(
                    getApplicationContext(),
                    R.drawable.onboarding_indicator_inactive
            ));
            indicators[i].setLayoutParams(layoutParams);
            layoutOnBoardingIndicators.addView(indicators[i]);
        }
    }

    private void setCurrentOnBoardingIndicator(int index) {
        int childCount = layoutOnBoardingIndicators.getChildCount();
        for (int i =0; i < childCount; i++) {
            ImageView imageView = (ImageView) layoutOnBoardingIndicators.getChildAt(i);
            if (i == index) {
                imageView.setImageDrawable(
                        ContextCompat.getDrawable(getApplicationContext(), R.drawable.onboarding_indicator_active)
                );
            } else {
                imageView.setImageDrawable(
                        ContextCompat.getDrawable(getApplicationContext(), R.drawable.onboarding_indicator_inactive)
                );
            }
        }
        if (index == onBoardingActivity.getItemCount() - 1) {
            buttonOnBoardingAction.setText("Начать");
        } else {
            buttonOnBoardingAction.setText("Дальше");
        }
    }

    public void startMapActivity(View v) {
        Intent intent = new Intent(this, MapActivity.class);
        startActivity(intent);
    }
}